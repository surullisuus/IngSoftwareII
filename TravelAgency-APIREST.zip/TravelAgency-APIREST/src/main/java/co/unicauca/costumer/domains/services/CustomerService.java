package co.unicauca.costumer.domains.services;


import co.unicauca.costumer.domain.entity.Customer;
import co.unicauca.customer.access.ICustomerRepository;
import java.util.List;
import javax.enterprise.context.RequestScoped;
import javax.enterprise.inject.Default;
import javax.inject.Inject;

/**
 * Es una fachada para comunicar la presentación con el
 * dominio
 *
 * @author Libardo Pantoja, Julio Hurtado
 */
@RequestScoped
public class CustomerService {

   


 
   
     /**
     * Inyecta una implementación del repositorio
     */
    @Inject
    @Default
    ICustomerRepository repo;

    /**
     * Constructor 
     */
    public CustomerService() {    }
    public List<Customer> findAll() {
        return repo.findAll();
    }
    /**
     * Buscar un cliente
     *
     * @param id cedula
     * @return objeto tipo Customer
     */
    public Customer findById(String id) {
        return repo.findById(id);
    }
    /**
     * Crea un nuevo customer.
     * @param cust 
     * @return devuelve un true o false si fue posible crear el cliente
     */
    public boolean create(Customer cust) {
        return repo.createCustomer(cust);
    }
    /**
     * Edita un customer.
     * @param cust 
     * @return devuelve devuelve un true o false si fue posible actualizar el cliente
     */
    public boolean update(Customer cust) {
        return repo.update(cust);
    }
    /**
     * Elimina un customer.
     * @param id cedula 
     * @return devuelve devuelve un true o false si fue posible eliminar el cliente
     */
    public boolean delete(String id) {
        return repo.delete(id);
    }

}
