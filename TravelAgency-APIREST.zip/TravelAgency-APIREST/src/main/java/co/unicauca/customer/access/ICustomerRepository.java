package co.unicauca.customer.access;

import co.unicauca.costumer.domain.entity.Customer;
import java.util.List;


/**
 * Interface del respositorio de clientes
 * @author Libardo Pantoja
 */
public interface ICustomerRepository {
    /**
     * Busca un Customer por su ceduka
     * @param id cedula del cliente
     * @return  objeto de tipo Customer
     */
  List<Customer> findAll();

    Customer findById(String id);

    boolean createCustomer(Customer newCustomer);

    boolean update(Customer newCustomer);

    boolean delete(String id);

}
