package co.unicauca.coustumer;

import javax.ws.rs.ApplicationPath;
import javax.ws.rs.core.Application;

/**
 * Configures Jakarta RESTful Web Services for the application.
 * @author Juneau
 */
@ApplicationPath("customer-service")
public class JakartaRestConfiguration extends Application {
    
}
